#!/usr/bin/env python3
"""No stock effect is hijacked by accident.

    python3 tools/verify/verify_replaces.py [remix ...]     (default: every remix, each built)
    python3 tools/verify/verify_replaces.py --static         (the registry only: make verify-shared)
    python3 tools/verify/verify_replaces.py --image REMIX    (the image on disk, out/mainos_bus.bin: make verify-remix)

Since 29 Sep 2026 `make check` runs the static half once in the shared half
and the image half per remix on the image that half has already built; it
built every remix in the shared half until then (402 s on a cold memo).

THE FAILURE THIS EXISTS FOR. The DSP dispatch tables are indexed by the raw
effect id and SHARED BY BOTH MENUS, so a module carrying a stock effect's id
replaces that effect wherever it is selected -- FX1 included -- and a remix
that omits the module then aliases the id to the fallback, taking the stock
effect away from FX1 too. Rungs sat on EQUALIZER's 0x0c and Nimbus on DJ EQ's
0x0d from 29 Aug to, in every local image. Every existing check
passed: the modules built, dispatched, rendered and sounded correct. What was
wrong was invisible from any one module's point of view.

WHAT IS CHECKED, per remix, per payload, for every stock effect id:

  * the module carrying it DECLARED it (MenuEntry.replaces naming that
    effect), or
  * the id is untouched -- FX2_IDS still points at the stock descriptor and
    the dispatch entries still hold the pristine image's values.

BOTH MENUS ARE CHECKED. FX1 resolves its own descriptors (FX1_IDS, and the
chooser list it scrolls), so an id can be correct on FX2 and wrong on FX1 --
which is the shape of the bug this file exists for. For a stock effect
nobody declared, FX1's two tables must read back the pristine image's
values; for a declared replacement, both must point at the module's clone
(or be left alone when FX1 does not list that effect at all).

THE ONE LEGITIMATE EXCEPTION is a donor reverb whose words this selection
took: PLATE/SPRING/DARK REV's code IS the donor region, so an id whose code
was overwritten is repointed at the null stub. That is allowed, and ONLY
that -- a donor id may be stock or the null stub, never anything else.

Static checks run with no image: a declared replacement must name a real
stock effect and carry that effect's id.
"""
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1])); import toolpath  # noqa: E402,F401  (every tools/ dir on sys.path)
from remix import registry, stock  # noqa: E402

BASE = 0x40000400
FX2_IDS = 0x400d5fdc
FX1_IDS = 0x400d5f58
FX1_LIST = 0x400d6060
FX1_NONE = 0x400d4618
PRISTINE = pathlib.Path("out/raw/section_3_MAIN_OS.bin")
# (tag, xtab, null init, null proc) -- build_bus.py's PAYLOADS
PAYLOADS = (("A", 0x400e2345, 0x007c8, 0x007c9),
            ("B", 0x400f5a10, 0x00588, 0x00589))
DONOR_IDS = {0x14, 0x15, 0x16}


def rd32(img, p):
    return int.from_bytes(img[p - BASE:p - BASE + 4], "big")


def rdw(img, p):
    return int.from_bytes(img[p - BASE:p - BASE + 3], "little")


# The three `lea` operands the firmware reads the FX1 chooser list from
# (build_bus.FX1_LIST_REFS). When a remix composes FX1 the list is rebuilt
# in the cave and these are repointed, so the LIVE list is what they name.
FX1_LIST_REFS = [0x40037990, 0x40052706, 0x40059bd2]


def _live_fx1_list(img):
    """Descriptor pointers of the FX1 chooser the built image actually
    draws: the list its first `lea` names, walked to the terminator."""
    out, a = [], rd32(img, FX1_LIST_REFS[0])
    while rd32(img, a) != 0 and len(out) < 32:
        out.append(rd32(img, a))
        a += 4
    return out


def _fx1_rows(pristine):
    """Addresses of the FX1 chooser list's entries, from the pristine image
    (the list is never relocated by build_bus -- a replacement rewrites a row
    in place -- so the pristine addresses are the live ones)."""
    out, a = [], FX1_LIST
    while rd32(pristine, a) != 0 and len(out) < 32:
        out.append(a)
        a += 4
    return out


def static_checks(fails):
    """A declared replacement must name a real stock effect, on its id."""
    for m in registry.modules().values():
        rep = m.menu.replaces if m.menu is not None else None
        if not rep:
            continue
        target = stock.BY_KEY.get(rep)
        if target is None:
            fails.append(f"{m.key}: replaces={rep!r}, which is not a stock "
                         f"effect (have: {', '.join(sorted(stock.BY_KEY))})")
        elif target.menu.fx2_id != m.menu.fx2_id:
            fails.append(
                f"{m.key}: replaces={rep!r} but carries id "
                f"0x{m.menu.fx2_id:02x}; {rep} is 0x{target.menu.fx2_id:02x}")
        else:
            print(f"  [PASS] {m.key} declares it replaces {rep} "
                  f"(id 0x{m.menu.fx2_id:02x})")


def check_image(name, img, pristine, fails):
    mods = registry.modules()
    remix = registry.remix(name)
    declared = {}
    for key in remix.modules:
        m = mods.get(key)
        if m is not None and m.menu is not None and m.menu.replaces:
            declared[m.menu.fx2_id] = m.key
    # WHAT THIS REMIX GIVES UP, derived from its two choosers exactly as the
    # build derives it: an effect on neither is one it does not want, so its
    # words are the region and its dispatch may legitimately be the null stub.
    _sp = stock.p_spans("A")
    _fx1_all = {k for k in _sp
                if mods[k].menu.fx2_id in stock.fx1_ids()}
    _given_up = set(stock.region_of(stock.harvested(
        set(remix.modules) | set(remix.fx1 or _fx1_all))))
    # schema.Module.dynamic_stock: every stock DSP effect is loaded on demand,
    # so its dispatch must be exactly the null stub until the loader binds it
    # (its native code is gone); DELAY runs on the ColdFire and stays stock.
    _dynamic = any(registry.modules()[k].dynamic_stock for k in remix.modules)
    _dsp = set(stock.p_spans("A"))
    for eff in stock.MODULES:
        eid = eff.menu.fx2_id
        want_desc = eff.menu.donor_desc + 0x38
        fx1_slot = FX1_IDS + eid * 4
        on_fx1 = rd32(pristine, fx1_slot) != FX1_NONE
        if eid in declared:
            # A declared replacement must have taken FX1 too, or FX1 would
            # run its code under the stock effect's knob names.
            if not on_fx1:
                continue
            got_id = rd32(img, fx1_slot)
            got_row = [rd32(img, a) for a in _fx1_rows(pristine)
                       if rd32(pristine, a) == want_desc]
            if got_id == want_desc:
                fails.append(
                    f"{name}: FX1_IDS[0x{eid:02x}] still points at stock "
                    f"{eff.key}, but {declared[eid]} replaces it -- FX1 would "
                    f"run the module under stock's knob names")
            if got_row and got_row[0] == want_desc:
                fails.append(
                    f"{name}: the FX1 chooser row for {eff.key} still points "
                    f"at stock's descriptor, but {declared[eid]} replaces it")
            # A COMPOSED FX1 chooser is rebuilt in the cave, so the row a
            # replacement inherited is whatever the composed list says:
            # the clone if the remix listed the replacement by name, no
            # row at all if it did not -- never stock's descriptor.
            if remix.fx1:
                _live = _live_fx1_list(img)
                _clone = rd32(img, FX2_IDS + eid * 4)
                if want_desc in _live:
                    fails.append(
                        f"{name}: the composed FX1 chooser still draws stock "
                        f"{eff.key}'s row, but {declared[eid]} replaces it")
                if (declared[eid] in remix.fx1) != (_clone in _live):
                    fails.append(
                        f"{name}: {declared[eid]} is "
                        f"{'' if declared[eid] in remix.fx1 else 'not '}in "
                        f"Remix.fx1 but its clone is "
                        f"{'' if _clone in _live else 'not '}in the composed "
                        f"FX1 list")
            if got_id != want_desc and (not got_row or got_row[0] != want_desc):
                print(f"  [PASS] {name}: {declared[eid]} took {eff.key}'s FX1 "
                      f"page as well as FX2's"
                      + (" and the composed chooser lists the clone"
                         if remix.fx1 and declared[eid] in remix.fx1 else ""))
            continue
        if on_fx1 and eff.key not in _given_up:
            for a in (fx1_slot,) + tuple(
                    x for x in _fx1_rows(pristine)
                    if rd32(pristine, x) == want_desc):
                if rd32(img, a) != rd32(pristine, a):
                    fails.append(
                        f"{name}: FX1 table at 0x{a:08x} ({eff.key}) is "
                        f"0x{rd32(img, a):08x}, not stock's "
                        f"0x{rd32(pristine, a):08x} -- nothing declared "
                        f"replaces={eff.key!r}")
        got_desc = rd32(img, FX2_IDS + eid * 4)
        if got_desc != want_desc:
            fails.append(
                f"{name}: FX2_IDS[0x{eid:02x}] ({eff.key}) is "
                f"0x{got_desc:08x}, not stock's 0x{want_desc:08x} -- nothing "
                f"in this remix declared replaces={eff.key!r}")
        for tag, xtab, nul_i, nul_p in PAYLOADS:
            for slot, nul in ((eid, nul_i), (32 + eid, nul_p)):
                got = rdw(img, xtab + slot * 3)
                want = rdw(pristine, xtab + slot * 3)
                if _dynamic and eff.key in _dsp:
                    if got != nul:
                        fails.append(
                            f"{name}: payload {tag} dispatch[0x{eid:02x}] ({eff.key}) is "
                            f"0x{got:05x}, not the null stub 0x{nul:05x} -- a dynamic-stock "
                            f"image loads every stock effect on demand")
                    continue
                if got == want:
                    continue
                if got == nul and eff.key in _given_up:
                    continue               # its words were taken; see above
                fails.append(
                    f"{name}: payload {tag} dispatch[0x{eid:02x}] "
                    f"({eff.key}) is 0x{got:05x}, not stock's 0x{want:05x}"
                    + (f" (nor the null stub 0x{nul:05x})"
                       if eff.key in _given_up else ""))


def main():
    if not PRISTINE.exists():
        sys.exit(f"missing {PRISTINE} -- run 'make setup'")
    pristine = PRISTINE.read_bytes()
    fails: list[str] = []
    args = sys.argv[1:]
    out = pathlib.Path("out/mainos_bus.bin")
    if args[:1] == ["--static"]:
        static_checks(fails)
        return report(fails)
    if args[:1] == ["--image"] and len(args) == 2:
        # the image the per-remix half built (make bus REMIX=...), checked as it is
        if not out.exists():
            sys.exit(f"verify_replaces: {out} is missing (make bus REMIX={args[1]})")
        before = len(fails)
        check_image(args[1], out.read_bytes(), pristine, fails)
        if len(fails) == before:
            print(f"  [PASS] {args[1]}: every stock id is stock's, or declared")
        return report(fails)
    static_checks(fails)
    names = args or [n for n in registry.remix_names()
                     if not n.startswith("_")]
    # ⚠️ EVERY BUILD HERE OVERWRITES THE SHIPPING ARTIFACT, and the checks
    # that run after this one read it. verify_burn already had to say so in
    # the Makefile; do it here instead, so the tool cleans up after itself
    # rather than the caller having to know. (audition.py uses the same
    # save-and-restore for its scratch builds.)
    saved = out.read_bytes() if out.exists() else None
    try:
        run(names, out, pristine, fails)
    finally:
        if saved is not None:
            out.write_bytes(saved)
    return report(fails)


def report(fails):
    print()
    for f in fails:
        print(f"  [FAIL] {f}")
    print("OK" if not fails else f"{len(fails)} FAILED")
    return 1 if fails else 0


def run(names, out, pristine, fails):
    import os
    import subprocess
    for name in names:
        env = {**os.environ, "REMIX": name, "XBUS": "1", "SPEC": "1"}
        r = subprocess.run([sys.executable, "tools/build/build_bus.py"],
                           capture_output=True, text=True, env=env)
        if r.returncode != 0:
            tail = (r.stdout + r.stderr).strip().splitlines()
            fails.append(f"{name}: build failed: {tail[-1] if tail else '?'}")
            continue
        before = len(fails)
        check_image(name, out.read_bytes(), pristine, fails)
        if len(fails) == before:
            print(f"  [PASS] {name}: every stock id is stock's, or declared")


if __name__ == "__main__":
    sys.exit(main())
