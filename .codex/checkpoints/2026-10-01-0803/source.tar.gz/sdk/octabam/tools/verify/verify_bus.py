#!/usr/bin/env python3
"""Bit-identity gate for the SHARED BUS scratch layout.

The same shape as tools/verify/verify_roll.py (reverb engine) and tools/verify/verify_delay.py
(delay engine), for the third thing that has no gate of its own: the bus itself
-- the parity word, the accumulator/wet buffers, the per-buffer send counts and
the three copies of the housekeeping block that must stay identical across
modules/send/send_client.asm, modules/busverb/reverb_server.asm and modules/busdelay/delay_server.asm.

It proves behaviour-preservation and says nothing about the cross-core
race: a green run is not evidence a timing fix works.

    make verify-bus SAVE=1     # on the tree you trust, BEFORE the edit
    ...make the bus change...
    make verify-bus            # must come back 19/19 bit-identical

An on-demand gate around one edit, not a member of `make check`: the
hashes cover the whole render (reverb engine, delay engine and bus
together, because the bus is only visible through a server), so any
voicing change to either engine fails it. Stamp, edit, compare, let the
reference go stale; it lives under out/ (gitignored).

The sensitivity nudge is the SEND level, the one knob every case carries
(a nudge on a delay knob leaves the seven reverb-only cases blind).
"""
import argparse
import hashlib
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1])); import toolpath  # noqa: E402,F401  (every tools/ dir on sys.path)

import send_probe  # noqa: E402

REF = ROOT / "out/dsp/bus_reference.json"
REF_MEM = ROOT / "out/dsp/mem_ref_A.mem"      # only needed by --allow-lag
DEV_MEM = ROOT / "out/dsp/mem_dev_A.mem"

# dsp_host caps a block at 15 frames, so one block is 15 samples here even
# though the accumulator buffers are 16 words wide for the hardware's 16.
BLOCK = send_probe.FRAMES

# Each case pins one property of the bus. The layout string is dispatch order,
# slot 0 being position 0 -- the housekeeper -- so varying it varies WHO elects
# itself, which is the part with three copies that must stay identical.
#
# `dur`/`tail` are short on purpose: this gate compares bytes, so it needs
# enough blocks to exercise several parity rotations, not enough to voice
# anything. Every case runs both servers' cross-sends where the layout allows.
CASES = [
    # --- who housekeeps -----------------------------------------------------
    ("RS      reverb is position 0 (housekeeper), one sender",
     dict(layout="RS")),
    ("SR      SEND is position 0 -- the other copy of the housekeeping block",
     dict(layout="SR")),
    ("DS      delay is position 0 -- the third copy",
     dict(layout="DS", pick="D")),
    ("SD      SEND housekeeps, delay is a plain client",
     dict(layout="SD", pick="D")),
    (".RS     position 0 is NEITHER -- the self-healing election takes over",
     dict(layout=".RS")),
    # ⚠️ NO SENDER AT POSITION 3 in any single-core case: that is track 8
    # on payload A (the DEV hatch IS payload A), where the SEND is refused
    # by design -- a `..DS` layout rendered digital silence and the gate
    # rightly refused to stamp it.
    (".DS     election takeover with the delay as the server",
     dict(layout=".DS", pick="D")),

    # --- the per-buffer counts and the 1/N auto-gain ------------------------
    # Sender count is the thing indexed by parity alongside the accumulators,
    # so a layout change that breaks the count indexing shows up here and
    # nowhere else. Swept because 1/N is a table lookup, not a formula.
    ("SSR     two senders -- 1/N = 1/2 on the reverb bus",
     dict(layout="SSR")),
    ("SSSR    three senders",
     dict(layout="SSSR")),
    ("SSS.SSSSR  seven senders -- the top of the reciprocal table (position 3 skipped)",
     dict(layout="SSS.SSSSR")),
    ("RSSS.SSSS  the same seven senders with the reverb at position 0 (23 Sep 2026: a ninth instance sits at X:0x7a00, a block no unit has)",
     dict(layout="RSSS.SSSS")),
    ("SSD     two senders into the delay bus",
     dict(layout="SSD", pick="D")),
    ("SSS.SSSSD  seven senders into the delay bus (position 3 skipped)",
     dict(layout="SSS.SSSSD", pick="D")),

    # --- the cross-sends: the paths that write the OTHER bus ----------------
    # ->VERB (delay writes the REVERB accumulator) and ->DEL (reverb writes the
    # DELAY accumulator) are the two places a client of one bus is a writer on
    # the other, so they are the cases a half-applied layout change survives.
    # (7 Sep 2026, one aux: the delay -> reverb hop is the hardwired CHAIN
    # buffer and needs no knob; the reverb's AUX is its host's own send.)
    ("RDS     both servers, reverb picked -- the delay's chain output lands",
     dict(layout="RDS", pick="R")),
    ("RDS/D   both servers, delay picked -- the reverb host's AUX write lands",
     dict(layout="RDS", pick="D", raux=64)),
    ("DRS     both servers, dispatch order reversed",
     dict(layout="DRS", pick="D", raux=64)),

    # --- split blocks: proc() runs twice, the bookkeeping actually executes --
    # split 0 never touches r7+$65/$66/$67, so a bug in the split-aware frame
    # offset is invisible without these. The offset is added to every bus
    # address, which is precisely what a layout change moves.
    ("RS s7   split block, reverb server",
     dict(layout="RS", split=7)),
    ("DS s7   split block, delay server",
     dict(layout="DS", pick="D", split=7)),
    ("RDS s5  split block with both servers and the chain",
     dict(layout="RDS", pick="D", split=5, raux=64)),

    # --- the hosts' own sends: paths every DEFAULT render leaves at zero ----
    # ⚠️ Added after the delay's IN decode was silently DELETED by
    # a splice (6d2690b) and every case still passed -- every case had IN at 0, so
    # "IN multiplies garbage" rendered identically to "IN works". A knob whose
    # default is 0 is INVISIBLE to this gate unless a case drives it.
    ("DS AUX  the delay host's own send, nonzero (inall)",
     dict(layout="DS", pick="D", din=64, inall=True)),
    ("RS AUX  the reverb host's own send, nonzero (inall)",
     dict(layout="RS", raux=64, inall=True)),
    ("RS MIX  the reverb's stage crossfade half way (the chain passthrough)",
     dict(layout="RS", mix=64)),
    ("DS MIX  the delay's stage crossfade half way",
     dict(layout="DS", pick="D", dmix=64)),

    # --- the engines' other arms (23 Sep 2026) -----------------------------
    # Every case above runs the delay in CLEAN and the reverb in its default
    # mode with SHMR and GATE at 0, so the GRAIN and REVERSE arms, PLATE, BIG,
    # the shimmer and the gate had no bit-identity gate; a pointer rewrite of
    # those arms needs one. Knobs held off their defaults so each arm's own
    # decode carries signal (SCTR/DENS/SIZE/PTCH for GRAIN, SIZE for
    # REVERSE, TONE/PING for the loop filters).
    ("DS GRAIN  the delay's GRAIN arm, scatter and wow driven",
     dict(layout="DS", pick="D", dmode=1, dspray=127, drate=100, dptch=1,
          dpitch=80, dtone=64, dping=64, dur=0.3)),
    ("DS GRAIN2 GRAIN at the smallest SIZE, pitch down, no scatter",
     dict(layout="DS", pick="D", dmode=1, dspray=0, drate=64, dptch=2,
          dpitch=40, dur=0.3)),
    ("DS REV   the delay's REVERSE arm",
     dict(layout="DS", pick="D", dmode=2, dptch=0, dtone=64,
          dur=0.3)),
    ("DS PING  CLEAN with PING and TONE driven",
     dict(layout="DS", pick="D", dping=100, dtone=40)),
    ("RS PLATE the reverb's PLATE mode with the shimmer",
     dict(layout="RS", rmode=1, shmr=64, rtone=40, dur=0.3)),
    ("RS BIG   the reverb's BIG mode with the gate and the width",
     dict(layout="RS", rmode=2, gate=64, width=100, rtone=90, dur=0.3)),
    ("RS GATE  ROOM with the gate closing on the tail",
     dict(layout="RS", gate=100, dur=0.3, tail=0.5)),

    # --- the chain hop under the reverb's hash, hot (23 Sep 2026) ---------
    # RDS s5 hashes the DELAY's print; nothing above hashed the REVERB's
    # print of a chain written across a split call, and every case ran at
    # amp 0.5. Image 58 clicked on the unit with a sample on the delay host
    # and its send up, heard in the reverb's wet; images 59/60 put it in
    # the delay rewrite. Full-scale tone, the host's own send at 127, FDBK
    # high, the reverb picked.
    ("RDS HOT  reverb picked, delay host send hot, full scale, split 5",
     dict(layout="RDS", pick="R", din=127, level=127, amp=1.0, split=5,
          dfdbk=100, dur=0.3)),
    ("RDS HOT2 the same with no split and the delay's WET at 0",
     dict(layout="RDS", pick="R", din=127, level=127, amp=1.0, dfdbk=100,
          dmix=0, rdly=0, dur=0.3)),     # rdly 0: the chain without the
                                         # repeats, which WET 0 gave until
                                         # DLY (25 Sep 2026)
    ("RDS HOT3 split 11, PING and TONE driven, both hosts sending",
     dict(layout="RDS", pick="R", din=127, raux=127, level=127, amp=1.0,
          split=11, dping=100, dtone=40, dur=0.3)),

    # --- the hosts' cross-sends (26 Sep 2026): T1's REV into the reverb,
    # T5's DEL into the delay. Both default to 0, so no case above drives
    # them; these two do, each hashed on the engine it feeds.
    ("RDS DREV the delay host's REV send, reverb picked, split 5",
     dict(layout="RDS", pick="R", drev=100, split=5, dur=0.3)),
    ("RDS RDEL the reverb host's DEL send, delay picked, split 5",
     dict(layout="RDS", pick="D", rdel=100, split=5, inall=True, dur=0.3)),
]

# Knobs held away from their defaults so the paths under test are actually
# carrying signal -- a case rendered at FDBK 0 through a silent send proves
# nothing about the accumulator it never reads.
BASE = dict(dur=0.12, tail=0.25, amp=0.5, level=100, dlevel=100,
            mix=127, dtime=20, dfdbk=70, din=40, dmix=127, raux=0)


def render(mem, case, bump_level=0, extra_send=""):
    kw = dict(BASE)
    kw.update(case)
    kw["level"] = kw["level"] + bump_level
    kw["dlevel"] = kw["dlevel"] + bump_level
    if extra_send:
        kw["layout"] = extra_send + kw["layout"]

    # Slots come from the manifests (the harness-knob-drift rule): the KEYS
    # keep their historical flag names, the indices follow the knob map.
    rk = send_probe._slots("REVERB SERVER", send_probe.REV_FLAGS)
    dk = send_probe._slots("DELAY SERVER", send_probe.DELAY_FLAGS)
    rev = list(send_probe.REV_PARAMS)
    rev[rk["time"]] = 40
    rev[rk["mix"]] = kw["mix"]                   # the stage crossfade
    rev[rk["raux"]] = kw["raux"]                 # 0 unless a case drives it:
                                                 # a phantom host client must
                                                 # NOT leak into every case
    for key in ("rmode", "shmr", "gate", "width", "rtone", "rdly", "rdel"):
        if key in kw:
            rev[rk[key]] = kw[key]
    snd = list(send_probe.SEND_PARAMS)
    snd[0] = kw["level"]             # DEL (dlevel is its alias)
    snd[1] = kw["level"]             # REV: the same level, both buses exercised
    dpar = list(send_probe.DELAY_PARAMS)
    for key in ("dtime", "dfdbk", "din", "dmix", "dtone", "dping", "dmode",
                "dspray", "drate", "dptch", "dpitch", "drev"):
        if key in kw:
            dpar[dk[key]] = kw[key]

    L, R = send_probe.run(str(mem), kw["dur"], kw["tail"], rev, snd,
                          verbose=False, amp=kw["amp"], direct=False,
                          wave_src=None, split=kw.get("split", 0),
                          layout=kw["layout"], delay_params=dpar,
                          pick=kw.get("pick"), inall=kw.get("inall", False))
    h = hashlib.sha256()
    for v in L:
        h.update(v.to_bytes(4, "little", signed=True))
    for v in R:
        h.update(v.to_bytes(4, "little", signed=True))
    # The hash alone cannot distinguish "identical" from "both silent", which
    # is the failure mode a bus change produces most often. Carry the peak so a
    # dead render is a loud error rather than a green tick.
    peak = max((abs(v) for v in L + R), default=0)
    # Samples are kept only when a lag search may need them -- 28 cases of raw
    # audio is a lot to hold for a run that is going to compare hashes.
    return h.hexdigest(), peak, len(L), (L, R)


def lag_match(cur_lr, ref_lr, max_lag):
    """Smallest shift (0..max_lag) at which the candidate IS the reference.

    The candidate is shifted LATER, which is the only direction a buffer moving
    further back down the rotation can go."""
    for lag in range(max_lag + 1):
        if all(c[lag:lag + len(r) - lag] == r[:len(r) - lag]
               for c, r in zip(cur_lr, ref_lr)):
            return lag
    return None


def collect(mem, keep_samples=False, **kw):
    out = {}
    for name, case in CASES:
        digest, peak, n, lr = render(mem, case, **kw)
        out[name] = dict(sha=digest, peak=peak, n=n)
        if keep_samples:
            out[name]["lr"] = lr
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--mem", default=str(DEV_MEM),
                    help="candidate dump (default: the DEV delay hatch)")
    ap.add_argument("--save", action="store_true",
                    help="stamp the candidate as the new reference")
    ap.add_argument("--selftest", action="store_true",
                    help="prove the harness can fail (see the module docstring)")
    ap.add_argument("--allow-lag", type=int, default=0, metavar="N",
                    help="accept a case that is bit-identical after shifting the\n"
                         "candidate LATER by up to N samples, and report the shift.\n"
                         "For deliberate LATENCY changes only -- moving the bus read\n"
                         "one buffer further back adds exactly one block, and this is\n"
                         "how you show that the added latency is the ONLY difference.\n"
                         "⚠️ A block here is 15 samples, not 16: dsp_host caps a block\n"
                         "at 15 frames (send_probe.FRAMES) while the accumulators are\n"
                         "16 words wide for the hardware's 16. Expecting 16 sent one\n"
                         "session chasing an off-by-one that did not exist.\n"
                         "⚠️ Engines with per-block state do NOT shift with the bus:\n"
                         "the reverb's LFOs advance once per block regardless, so its\n"
                         "cases legitimately fail this while the delay's pass. Prove\n"
                         "the restructure separately, at zero lag, by pointing the read\n"
                         "at the same buffer generation as the reference.")
    a = ap.parse_args()

    mem = pathlib.Path(a.mem)
    if not mem.exists():
        sys.exit(f"missing {mem} -- build the hatch first:\n"
                 f"  DEV=1 XBUS=1 python3 tools/build/build_bus.py")

    print(f"bus gate: {len(CASES)} cases against {mem.relative_to(ROOT)}")
    if a.allow_lag and not a.save:
        # A lag search needs the reference's SAMPLES, and the stamped file holds
        # only hashes -- so the reference build has to still be on disk. Rather
        # than guess where, require it explicitly: silently comparing against
        # the candidate would report lag 0 for everything.
        if not REF_MEM.exists():
            sys.exit(f"--allow-lag needs the reference dump's samples, not just\n"
                     f"its hashes. Put the build the reference was stamped from\n"
                     f"at {REF_MEM.relative_to(ROOT)} and rerun.")
    cur = collect(mem, keep_samples=bool(a.allow_lag))

    dead = [k for k, v in cur.items() if v["peak"] == 0]
    if dead:
        print("\n  DEAD RENDERS -- these cases produced digital silence, so a\n"
              "  matching hash would prove nothing:")
        for k in dead:
            print(f"    {k}")
        sys.exit(1)

    if a.save:
        REF.parent.mkdir(parents=True, exist_ok=True)
        REF.write_text(json.dumps(cur, indent=1, sort_keys=True))
        print(f"  wrote {REF.relative_to(ROOT)} ({len(cur)} cases)")
        for name, v in sorted(cur.items()):
            print(f"    {name:52s} peak {v['peak']:8d}  {v['sha'][:16]}")
        return 0

    if not REF.exists():
        sys.exit(f"no reference at {REF.relative_to(ROOT)} -- stamp one with --save\n"
                 f"(do that on a build you TRUST, not on the candidate)")
    ref = json.loads(REF.read_text())

    if a.selftest:
        print("\n  SELFTEST -- both perturbations MUST fail:")
        ok = True
        for label, kw in (("knob nudge (send level +1)", dict(bump_level=1)),
                          ("one extra SEND on the bus", dict(extra_send="S"))):
            per = collect(mem, **kw)
            same = [k for k in ref if k in per and per[k]["sha"] == ref[k]["sha"]]
            if same:
                print(f"    ✗ {label}: {len(same)} case(s) STILL MATCHED -- "
                      f"the harness is blind to them:")
                for k in same:
                    print(f"        {k}")
                ok = False
            else:
                print(f"    ✓ {label}: all {len(per)} cases changed")
        if not ok:
            print("\n  THE HARNESS IS NOT MEASURING WHAT IT CLAIMS TO. Fix it "
                  "before trusting a green run.")
            return 1
        print("  selftest passed: the harness can fail.")

    refsamp = {}
    if a.allow_lag:
        print(f"  reference samples from {REF_MEM.relative_to(ROOT)}")
        for k, v in collect(REF_MEM, keep_samples=True).items():
            refsamp[k] = v["lr"]

    print()
    bad, lagged = [], []
    for name, _ in CASES:
        c = cur[name]
        r = ref.get(name)
        if r is None:
            print(f"  NEW   {name:52s} (not in the reference)")
            continue
        if c["sha"] == r["sha"]:
            print(f"  ok    {name:52s} peak {c['peak']:8d}")
        elif a.allow_lag:
            lag = lag_match(c["lr"], refsamp[name], a.allow_lag)
            if lag is None:
                print(f"  FAIL  {name:52s} peak {c['peak']:8d} vs ref "
                      f"{r['peak']:8d}  (no lag <= {a.allow_lag} matches)")
                bad.append(name)
            else:
                print(f"  ok    {name:52s} peak {c['peak']:8d}  "
                      f"BIT-IDENTICAL at lag {lag} ({lag / BLOCK:g} block)")
                lagged.append((name, lag))
        else:
            print(f"  FAIL  {name:52s} peak {c['peak']:8d} vs ref {r['peak']:8d}")
            bad.append(name)

    missing = [k for k in ref if k not in cur]
    for k in missing:
        print(f"  GONE  {k:52s} (in the reference, not in this run)")

    if bad or missing:
        print(f"\n  {len(bad)} case(s) differ, {len(missing)} missing -- the "
              f"candidate is NOT bit-identical to the reference.")
        print("  Note what this does and does not mean: a FAIL here is a real\n"
              "  behaviour change. A PASS says nothing about cross-core timing,\n"
              "  which no local test can reach.")
        return 1

    if lagged:
        lags = sorted({l for _, l in lagged})
        print(f"\n  {len(lagged)} case(s) bit-identical only after a shift: "
              f"lag {lags} samples.")
        print("  That is a LATENCY change and nothing else -- every sample of "
              "those\n  renders is the reference's, just later.")
    print(f"\n  all {len(CASES)} cases bit-identical to the reference.")
    print("  ⚠️  This proves the bus still DOES the same thing. It does NOT\n"
          "     prove anything about the cross-core race -- this gate runs\n"
          "     one core, and even two emulated cores are never the chip's timing.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
