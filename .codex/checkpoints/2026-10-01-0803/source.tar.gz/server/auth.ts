import type { Env, User, Database } from './platform'
import { apiOrigin, appUrl, cookie, digest, getCookie, HttpError, jsonBody, response, sessionValue, token } from './security'
export function isAdmin(user:User|null,env:Env){return !!user?.github_id&&!!env.ADMIN_GITHUB_ID&&user.github_id===env.ADMIN_GITHUB_ID}
export async function currentUser(request:Request,db:Database):Promise<User|null>{
 const value=sessionValue(request);if(!/^[a-f0-9]{64}$/.test(value))return null
 return db.prepare('SELECT u.* FROM users u JOIN sessions s ON s.user_id=u.id WHERE s.token_hash=? AND s.expires>?').bind(await digest(value),Math.floor(Date.now()/1000)).first<User>()
}
export async function throttle(db:Database,key:string,maximum:number,seconds=3600){
 const now=Math.floor(Date.now()/1000),bucket=Math.floor(now/seconds)
 const result=await db.prepare('INSERT INTO rate_limits(key,count,expires) VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET count=count+1 RETURNING count').bind(await digest(key+':'+bucket),now+seconds).first<{count:number}>()
 if(!result||result.count>maximum)throw new HttpError(429,'Too many requests. Please try again later.')
}
async function createSession(user:User,env:Env,db:Database){
 const value=token(),seconds=30*24*60*60
 await db.prepare('INSERT INTO sessions(token_hash,user_id,expires) VALUES(?,?,?)').bind(await digest(value),user.id,Math.floor(Date.now()/1000)+seconds).run()
 return { cookie: env.SESSION_TRANSPORT === 'bearer' ? undefined : cookie('octamod_session',value,env,seconds), sessionToken: env.SESSION_TRANSPORT === 'bearer' ? value : undefined }
}
export async function guest(request:Request,env:Env,db:Database,name:string):Promise<{user:User;cookie?:string;sessionToken?:string}>{
 const existing=await currentUser(request,db);if(existing)return {user:existing}
 await throttle(db,'visitor:'+ (request.headers.get('CF-Connecting-IP')??'local'),20,3600)
 const user:User={id:crypto.randomUUID(),display_name:name,github_id:null,github_login:null}
 await db.prepare('INSERT INTO users(id,display_name) VALUES(?,?)').bind(user.id,name).run()
 return {user,...await createSession(user,env,db)}
}
export async function authentication(request:Request,env:Env,path:string):Promise<Response|null>{
 const db=env.DB
 if(path==='/api/auth/session'&&request.method==='GET'){
  const user=db?await currentUser(request,db):null
  return response({available:!!db,githubEnabled:!!(db&&env.GITHUB_CLIENT_ID&&env.GITHUB_CLIENT_SECRET&&env.APP_URL),user:user?{id:user.id,displayName:user.display_name,githubLogin:user.github_login,isAdmin:isAdmin(user,env)}:null})
 }
 if(!path.startsWith('/api/auth/'))return null
 if(!db)throw new HttpError(503,'Community storage is not connected yet.')
 if(path==='/api/auth/complete'&&request.method==='POST'){
  if(env.SESSION_TRANSPORT !== 'bearer') throw new HttpError(404,'Authentication route not found.')
  await throttle(db,'sign-in:'+(request.headers.get('CF-Connecting-IP')??'local'),30,600)
  const body=await jsonBody(request)
  if(typeof body.grant!=='string'||!/^[a-f0-9]{64}$/.test(body.grant)||typeof body.verifier!=='string'||!/^[a-f0-9]{64}$/.test(body.verifier))throw new HttpError(403,'This sign-in has expired. Start GitHub sign-in again.')
  const grant=await db.prepare('DELETE FROM sign_in_grants WHERE token_hash=? AND challenge=? AND expires>? RETURNING user_id').bind(await digest(body.grant),await digest(body.verifier),Math.floor(Date.now()/1000)).first<{user_id:string}>()
  if(!grant)throw new HttpError(403,'This sign-in has expired. Start GitHub sign-in again.')
  const user=await db.prepare('SELECT * FROM users WHERE id=?').bind(grant.user_id).first<User>()
  if(!user)throw new HttpError(403,'This sign-in has expired. Start GitHub sign-in again.')
  const session=await createSession(user,env,db),result=response({ok:true})
  result.headers.set('X-Octamod-Session',session.sessionToken!)
  return result
 }
 if(path==='/api/auth/logout'&&request.method==='POST'){
  await db.prepare('DELETE FROM sessions WHERE token_hash=?').bind(await digest(sessionValue(request))).run()
  const result=response({ok:true});result.headers.set('X-Octamod-Session','');if(env.SESSION_TRANSPORT!=='bearer')result.headers.append('Set-Cookie',cookie('octamod_session','',env,0));return result
 }
 if(path==='/api/auth/github'&&request.method==='GET'){
  if(!env.GITHUB_CLIENT_ID||!env.GITHUB_CLIENT_SECRET)throw new HttpError(503,'GitHub sign-in has not been configured yet.')
  const state=token(),verifier=token(),returnPath=new URL(request.url).searchParams.get('return')??'submit'
  const browserChallenge=new URL(request.url).searchParams.get('challenge')??''
  if(env.SESSION_TRANSPORT==='bearer'&&!/^[a-f0-9]{64}$/.test(browserChallenge))throw new HttpError(400,'Start GitHub sign-in from Octamod.')
  const safeReturn=/^(submit(?:\/[a-z0-9-]+)?|account|review|admin)$/.test(returnPath)?returnPath:'submit'
  const hash=new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(verifier)))
  const challenge=btoa(String.fromCharCode(...hash)).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')
  const url=new URL('https://github.com/login/oauth/authorize')
  url.search=new URLSearchParams({client_id:env.GITHUB_CLIENT_ID,redirect_uri:apiOrigin(env)+'/api/auth/github/callback',scope:'read:user',state,code_challenge:challenge,code_challenge_method:'S256'}).toString()
  return new Response(null,{status:302,headers:{Location:url.href,'Set-Cookie':cookie('octamod_oauth',state+'.'+verifier+'.'+encodeURIComponent(safeReturn)+'.'+browserChallenge,env,600),'Cache-Control':'no-store'}})
 }
 if(path==='/api/auth/github/callback'&&request.method==='GET'){
  const url=new URL(request.url),state=url.searchParams.get('state'),code=url.searchParams.get('code'),[savedState,verifier,encodedReturn,browserChallenge]=getCookie(request,'octamod_oauth').split('.')
  if(!state||!code||state!==savedState||!/^[a-f0-9]{64}$/.test(verifier??''))throw new HttpError(403,'The GitHub sign-in state is invalid. Start sign-in again.')
  const exchange=await fetch('https://github.com/login/oauth/access_token',{method:'POST',headers:{Accept:'application/json','Content-Type':'application/json'},body:JSON.stringify({client_id:env.GITHUB_CLIENT_ID,client_secret:env.GITHUB_CLIENT_SECRET,code,code_verifier:verifier,redirect_uri:apiOrigin(env)+'/api/auth/github/callback'})})
  const grant=await exchange.json() as {access_token?:string};if(!exchange.ok||!grant.access_token)throw new HttpError(401,'GitHub could not authorize this sign-in.')
  const profileResponse=await fetch('https://api.github.com/user',{headers:{Authorization:'Bearer '+grant.access_token,Accept:'application/vnd.github+json','User-Agent':'Octamod'}})
  if(!profileResponse.ok)throw new HttpError(502,'GitHub account details could not be read.')
  const profile=await profileResponse.json() as {id:number;login:string}
  if(!Number.isSafeInteger(profile.id)||!profile.login)throw new HttpError(502,'GitHub returned invalid account details.')
  await db.prepare('INSERT INTO users(id,display_name,github_id,github_login) VALUES(?,?,?,?) ON CONFLICT(github_id) DO UPDATE SET github_login=excluded.github_login,display_name=excluded.display_name').bind(crypto.randomUUID(),profile.login,String(profile.id),profile.login).run()
  const user=await db.prepare('SELECT * FROM users WHERE github_id=?').bind(String(profile.id)).first<User>()
  if(!user)throw new HttpError(500,'Unable to open your contributor session.')
  const returnPath=decodeURIComponent(encodedReturn??'submit'),safeReturn=/^(submit(?:\/[a-z0-9-]+)?|account|review|admin)$/.test(returnPath)?returnPath:'submit'
  let location=appUrl(env)+'#'+safeReturn
  const headers=new Headers({'Cache-Control':'no-store','Referrer-Policy':'no-referrer'})
  if(env.SESSION_TRANSPORT==='bearer'){
   if(!/^[a-f0-9]{64}$/.test(browserChallenge??''))throw new HttpError(403,'Start GitHub sign-in from Octamod.')
   const grant=token(),now=Math.floor(Date.now()/1000)
   await db.prepare('DELETE FROM sign_in_grants WHERE expires<=?').bind(now).run()
   await db.prepare('INSERT INTO sign_in_grants(token_hash,user_id,challenge,expires) VALUES(?,?,?,?)').bind(await digest(grant),user.id,browserChallenge,now+120).run()
   location=appUrl(env)+'#auth/complete?'+new URLSearchParams({grant,return:safeReturn})
  }else{headers.append('Set-Cookie',(await createSession(user,env,db)).cookie!)}
  headers.set('Location',location);headers.append('Set-Cookie',cookie('octamod_oauth','',env,0))
  return new Response(null,{status:303,headers})
 }
 throw new HttpError(404,'Authentication route not found.')
}
