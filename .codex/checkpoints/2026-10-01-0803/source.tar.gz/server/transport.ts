import { handleApi } from './api'
import type { Env } from './platform'
import { appOrigin, HttpError, response } from './security'
/** One trusted website origin, including failure responses and preflights. */
export async function handleCommunity(request: Request, env: Env): Promise<Response> {
  let allowed: string
  try { allowed = appOrigin(env) } catch (error) { return response({ error: error instanceof Error ? error.message : 'Service unavailable.' }, 503) }
  const origin = request.headers.get('Origin')
  if (origin && origin !== allowed) return response({ error: 'This request did not originate from Octamod.' }, 403)
  let result: Response
  if (request.method === 'OPTIONS') {
    const method = request.headers.get('Access-Control-Request-Method') ?? ''
    const headers = (request.headers.get('Access-Control-Request-Headers') ?? '').split(',').map(value => value.trim().toLowerCase()).filter(Boolean)
    if (origin !== allowed || !['GET', 'POST', 'PUT', 'PATCH', 'DELETE'].includes(method) || headers.some(header => !['authorization', 'content-type'].includes(header))) return response({ error: 'Preflight not allowed.' }, 403)
    result = new Response(null, { status: 204 })
    result.headers.set('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE')
    result.headers.set('Access-Control-Allow-Headers', 'Authorization, Content-Type')
    result.headers.set('Access-Control-Max-Age', '600')
  } else {
    try { result = await handleApi(request, env) }
    catch (error) { result = response({ error: error instanceof HttpError ? error.message : 'The request could not be completed.' }, error instanceof HttpError ? error.status : 500) }
  }
  const headers = new Headers(result.headers)
  headers.set('Vary', 'Origin')
  if (origin === allowed) {
    headers.set('Access-Control-Allow-Origin', allowed)
    headers.set('Access-Control-Expose-Headers', 'X-Octamod-Session')
  }
  return new Response(result.body, { status: result.status, statusText: result.statusText, headers })
}
