import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  base: './',
  server: { fs: { deny: ['.env', '.env.*', '.dev.vars', '.dev.vars.*', '**/*.crt', '**/*.pem', '**/*.key', '**/*.bin', '**/*.syx', '**/.git/**', '**/downloads/**', '**/out/**'] }, port: 5173, strictPort: true, proxy: { '/api': 'http://127.0.0.1:8788' } },
  build: { sourcemap: false },
})
