import { apiUrl, communityBase } from '../hosting'
const sessionKey = () => 'octamod.community.session:' + communityBase()
function savedSession() { try { return localStorage.getItem(sessionKey()) ?? '' } catch { return '' } }
export async function apiFetch(path: string, options: RequestInit = {}): Promise<Response> {
  const headers = new Headers(options.headers), session = savedSession()
  if (/^[a-f0-9]{64}$/.test(session)) headers.set('Authorization', 'Bearer ' + session)
  let result: Response
  try { result = await fetch(apiUrl(path), { ...options, headers, credentials: 'same-origin', redirect: 'error' }) }
  catch { throw new Error('Community services are not connected yet. Your local workspace still works.') }
  const next = result.headers.get('X-Octamod-Session')
  if (result.ok && next !== null) {
    try { if (/^[a-f0-9]{64}$/.test(next)) localStorage.setItem(sessionKey(), next); else if (next === '') localStorage.removeItem(sessionKey()) }
    catch { throw new Error('Your browser could not save this community session. Enable site storage to keep ownership of posts.') }
  }
  return result
}
export async function api<T>(path: string, options: RequestInit = {}): Promise<T> {
  const result = await apiFetch(path, options)
  let body: T & { error?: string }
  try { body = await result.json() as T & { error?: string } }
  catch { throw new Error('Community services are not connected yet. Your local workspace still works.') }
  if (!result.ok) throw new Error(body.error ?? 'The request could not be completed.')
  return body
}
export function post<T>(path: string, body: unknown, method = 'POST') { return api<T>(path, { method, headers: { 'Content-Type':'application/json' }, body: JSON.stringify(body) }) }
export type CommunityUser = { id: string; displayName: string; githubLogin: string | null; isAdmin: boolean }
export type Session = { available: boolean; githubEnabled: boolean; user: CommunityUser | null }
export type PublicMedia = { id: string; kind: 'image' | 'audio'; caption: string; capture_type: string }
export type PublishedModule = { module_id: string; title: string; repository_url: string; description: string; usage: string; resource_notes: string; test_report_url: string; reviewed_at: string; author: string }
