import { useEffect, useState } from 'react'
import type { ReactNode } from 'react'
import { api } from './api'
import { completeGitHubSignIn } from './sign-in'
import type { PublishedModule, Session } from './api'
import { CommunityContext, emptySession } from './context'
export function CommunityProvider({children}:{children:ReactNode}){
 const [session,setSession]=useState(emptySession),[catalog,setCatalog]=useState<PublishedModule[]>([]),[signInError,setSignInError]=useState('')
 async function refresh(){try{const next=await api<Session>('/auth/session');setSession(next);if(next.available)setCatalog(await api<PublishedModule[]>('/catalog'))}catch{setSession(emptySession)}}
 useEffect(()=>{let cancelled=false;void completeGitHubSignIn().catch(error=>{if(!cancelled)setSignInError(error instanceof Error?error.message:'Sign-in could not be completed.')}).then(()=>api<Session>('/auth/session')).then(next=>{if(cancelled)return;setSession(next);if(next.available)void api<PublishedModule[]>('/catalog').then(items=>{if(!cancelled)setCatalog(items)}).catch(()=>{})}).catch(()=>{});return()=>{cancelled=true}},[])
 return <CommunityContext.Provider value={{session,catalog,refresh}}>{signInError&&<p className="file-error" role="alert">{signInError} <button className="text-button" onClick={()=>setSignInError('')}>Dismiss</button></p>}{children}</CommunityContext.Provider>
}
