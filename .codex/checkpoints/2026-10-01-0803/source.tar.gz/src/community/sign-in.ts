import { apiUrl } from '../hosting'
import { post } from './api'
const key = 'octamod.sign-in.verifier'
const safeRoute = (route: string) => /^(submit(?:\/[a-z0-9-]+)?|account|review|admin)$/.test(route) ? route : 'submit'
export async function startGitHubSignIn(returnRoute = 'submit') {
  const verifier = Array.from(crypto.getRandomValues(new Uint8Array(32)), byte => byte.toString(16).padStart(2, '0')).join('')
  sessionStorage.setItem(key, verifier)
  const challenge = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier))), byte => byte.toString(16).padStart(2, '0')).join('')
  window.location.assign(apiUrl('/auth/github?') + new URLSearchParams({ return: safeRoute(returnRoute), challenge }))
}
let completing: Promise<void> | undefined
export function completeGitHubSignIn(): Promise<void> {
  if (completing) return completing
  if (!window.location.hash.startsWith('#auth/complete?')) return Promise.resolve()
  const params = new URLSearchParams(window.location.hash.slice('#auth/complete?'.length))
  // Remove the single-use grant immediately. A session token never enters a URL.
  const route = safeRoute(params.get('return') ?? 'submit')
  history.replaceState(null, '', window.location.pathname + window.location.search + '#' + route)
  window.dispatchEvent(new Event('hashchange'))
  completing = (async () => {
    const verifier = sessionStorage.getItem(key)
    sessionStorage.removeItem(key)
    if (!verifier) throw new Error('This sign-in belongs to another tab or has expired. Start GitHub sign-in again.')
    await post('/auth/complete', { grant: params.get('grant'), verifier })
  })()
  return completing
}
